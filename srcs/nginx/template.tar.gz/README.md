2 Blocks Template
=========

A template split in 2 animated blocks of content, inspired by dropbox.com/guide.

[Article on CodyHouse](http://codyhouse.co/gem/2-blocks-template/)

[Demo](http://codyhouse.co/demo/2-blocks-template/index.html)

Images: [Unsplash](https://unsplash.com/)
 
[Terms](http://codyhouse.co/terms/)
